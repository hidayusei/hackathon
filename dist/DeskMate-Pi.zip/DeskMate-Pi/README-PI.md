# DeskMate Raspberry Pi 5版

このフォルダだけでDeskMateを実行できます。Windows用ファイル、テスト、設計書、
GIF生成用のPNGは含まれていません。

## 前提

- Raspberry Pi 5
- 64-bit Raspberry Pi OS / Prophesee公式イメージ
- GenX320、ドライバ、OpenEB、Metavision SDKが導入済み
- `metavision_viewer`でライブ表示を確認済み
- インターネット接続（初回のPython依存関係インストール時）

## 1. 解凍

```bash
unzip DeskMate-Pi.zip
cd DeskMate-Pi
```

## 2. カメラを準備

環境に合わせてGenX320を接続し、次を実行します。

```bash
sudo dtoverlay genx320,cam0
cd ~/rpi-sensor-drivers
./rp5_setup_v4l.sh
export PSEE_VAR_V4L2_BSIZE=1
metavision_viewer
```

`metavision_viewer`で映像が出ることを確認して閉じてください。

## 3. DeskMateをインストール

```bash
cd ~/DeskMate-Pi
bash install-pi.sh
```

Metavision SDKを仮想環境から利用するため、セットアップは
`--system-site-packages`付きで仮想環境を作ります。

## 4. 接続確認と起動

```bash
./check-pi.sh
./run-pi.sh
```

右クリックから詳細、停止・再開、終了、UIデバッグを操作できます。

## カメラなしでUIだけ確認

```bash
./run-demo.sh
```

集中・非集中・離席中と休憩促しを順番に表示します。右クリックの
「UIデバッグ」から各表示を直接選ぶこともできます。

## RAW録画の再生

```bash
./run-pi.sh --raw /path/to/recording.raw
```

## トラブル時

- `Metavision SDK: NG`: Prophesee公式環境のPythonから
  `metavision_core`がimportできるか確認してください。
- `V4L2デバイス: NG`: `dtoverlay`と`rp5_setup_v4l.sh`を再確認してください。
- `GUIセッション: NG`: SSHだけでなく、Piのデスクトップ上のターミナルから起動してください。
- `CAMERA ERROR`: `metavision_viewer`を閉じ、カメラを他のアプリが使用していないか確認してください。

DeskMateはカメラ取得に失敗しても、黙ってダミー入力へ切り替えません。
