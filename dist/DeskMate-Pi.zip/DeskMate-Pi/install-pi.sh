#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

if [[ "$(uname -s)" != "Linux" ]]; then
    echo "エラー: このセットアップはRaspberry Pi OS上で実行してください。" >&2
    exit 1
fi

case "$(uname -m)" in
    aarch64|arm64) ;;
    *)
        echo "警告: Raspberry Pi 5の64-bit OS（aarch64）以外で実行されています。" >&2
        ;;
esac

if ! command -v python3 >/dev/null 2>&1; then
    echo "エラー: python3が見つかりません。" >&2
    exit 1
fi

if ! python3 -c 'import sys; raise SystemExit(not ((3, 11) <= sys.version_info[:2] < (3, 14)))'
then
    echo "エラー: Python 3.11〜3.13が必要です。" >&2
    exit 1
fi

if [[ ! -d .venv ]]; then
    python3 -m venv --system-site-packages .venv
fi

.venv/bin/python -m pip install --upgrade pip setuptools
.venv/bin/python -m pip install -e .

chmod +x run-pi.sh run-demo.sh check-pi.sh

echo
echo "DeskMateのインストールが完了しました。"
echo "次にカメラ準備後、次の順で実行してください:"
echo "  ./check-pi.sh"
echo "  ./run-pi.sh"
