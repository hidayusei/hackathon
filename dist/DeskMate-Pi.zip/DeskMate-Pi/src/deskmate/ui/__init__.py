"""DeskMate Qt user interface."""
