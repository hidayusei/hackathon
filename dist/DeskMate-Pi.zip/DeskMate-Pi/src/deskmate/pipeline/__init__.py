"""DeskMate event-processing pipeline."""
