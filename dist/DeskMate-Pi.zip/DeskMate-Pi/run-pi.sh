#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

if [[ ! -x .venv/bin/python ]]; then
    echo "先に bash install-pi.sh を実行してください。" >&2
    exit 1
fi

if [[ -z "${DISPLAY:-}" && -z "${WAYLAND_DISPLAY:-}" ]]; then
    echo "GUIセッション内のターミナルから実行してください。" >&2
    exit 1
fi

export PSEE_VAR_V4L2_BSIZE="${PSEE_VAR_V4L2_BSIZE:-1}"
exec .venv/bin/python -m deskmate \
    --config config/pi.yaml \
    --source metavision \
    "$@"
