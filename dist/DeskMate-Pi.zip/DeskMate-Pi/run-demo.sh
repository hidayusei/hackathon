#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

if [[ ! -x .venv/bin/python ]]; then
    echo "先に bash install-pi.sh を実行してください。" >&2
    exit 1
fi

exec .venv/bin/python -m deskmate \
    --config config/pi.yaml \
    --demo \
    --break-demo \
    "$@"
