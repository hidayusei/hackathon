#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

failed=0

check() {
    local label="$1"
    shift
    if "$@" >/dev/null 2>&1; then
        printf 'OK   %s\n' "$label"
    else
        printf 'NG   %s\n' "$label"
        failed=1
    fi
}

check "Linux" test "$(uname -s)" = "Linux"
check "64-bit ARM" bash -c '[[ "$(uname -m)" == "aarch64" || "$(uname -m)" == "arm64" ]]'
check "DeskMate仮想環境" test -x .venv/bin/python
check "DeskMate実行依存" .venv/bin/python -c \
    'import numpy, pyqtgraph, pydantic, yaml, PySide6, deskmate'
check "Metavision SDK" .venv/bin/python -c \
    'from metavision_core.event_io import EventsIterator'
check "既定設定" test -f config/default.yaml
check "Pi設定" test -f config/pi.yaml
check "キャラクターGIF" bash -c \
    'for f in running sitting sleeping break; do test -s "assets/character/${f}.gif" || exit 1; done'

if [[ -z "${DISPLAY:-}" && -z "${WAYLAND_DISPLAY:-}" ]]; then
    echo "NG   GUIセッション（DISPLAY/WAYLAND_DISPLAY）"
    failed=1
else
    echo "OK   GUIセッション"
fi

if compgen -G '/dev/video*' >/dev/null; then
    echo "OK   V4L2デバイス"
else
    echo "NG   V4L2デバイス（dtoverlayとrp5_setup_v4l.shを確認）"
    failed=1
fi

if (( failed != 0 )); then
    echo
    echo "未準備の項目があります。README-PI.mdの手順を確認してください。" >&2
    exit 1
fi

echo
echo "基本確認はすべて成功しました。./run-pi.sh で起動できます。"
