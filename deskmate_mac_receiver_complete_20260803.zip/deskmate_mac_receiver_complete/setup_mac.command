#!/bin/bash
set -eu
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 が見つかりません。Python 3.11〜3.13を先にインストールしてください。"
  read -r -p "Enterキーで閉じます..."
  exit 1
fi

python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -e .

echo "セットアップが完了しました。start_receiver.command で起動できます。"
read -r -p "Enterキーで閉じます..."
