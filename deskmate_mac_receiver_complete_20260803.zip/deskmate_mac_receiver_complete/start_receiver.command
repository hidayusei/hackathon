#!/bin/bash
set -eu
cd "$(dirname "$0")"

if [ ! -x ".venv/bin/python" ]; then
  echo ".venv が見つかりません。"
  echo "先に次を実行してください: python3 -m venv .venv"
  read -r -p "Enterキーで閉じます..."
  exit 1
fi

exec .venv/bin/python -m deskmate --config pc-udp.yaml --show-event-camera
